Design - takes in input of throughput, rtt, and connection_status and
adds the values to a dictionary, so we can later calculate the average and
standard deviation for each. Currently no known issues.

docstrings included for the TestResultContainer class file
comments in the main

Evaluation Case 1:
  Throughput
    avg: 3.833
    std: 1.504
  RTT
    avg: 11.033
    std: 1.002
  Connection Status:
    avg: 25.6
    std: 1.682


Evaluation Case 2:
  Throughput
    avg: 3.755
    std: 1.034
  RTT
    avg: 14.325
    std: 4.394
  Connection Status:
    avg: 20.692
    std: 5.822
